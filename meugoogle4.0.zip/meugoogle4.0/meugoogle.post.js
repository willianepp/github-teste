// check that search term has been provided

model.pesquisa = "";

if (args.q == undefined || args.q.length == 0) {
	status.code = 400;
	status.message = "Search term has not been provided.";
	//status.redirect = true;
	status.redirect = false;
} else {
	// perform search
	//var nodes = search.childrenbyLuceneSearch("TEXT:" + args.q);
	if (args.q) {
		var nodes = search.luceneSearch("workspace://SpacesStore","TEXT:" + args.q);
		model.resultset = nodes;
                model.pesquisa = args.q;
	}
}
